import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const routers = new Router({
  base: __dirname,
  routes: [
    {
      path: '/roadmore',
      component: (resolve) => { require(['../page/loadmore'], resolve) }
    }
  ]
})

export default routers
