<template>
    <div class="sdf">
        11111111123456 飞
        <p>ssasadsadsads</p>
        <p>ssasadsadsads</p>
        <p>ssasadsadsads</p>
        <p>ssasadsadsads</p>
        <p>ssasadsadsads</p>
    </div>

</template>

<script>
export default {
  name: 'loadmore'
}
</script>

<style lang="css">
</style>
