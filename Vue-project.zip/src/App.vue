<template>
<div id="app" :class="[appClass]">
  <transition>
    <keep-alive :include="`ss`">
      <router-view class="router-view"></router-view>
    </keep-alive>
  </transition>
</div>
</template>

<script>
export default {
  created () {
      console.log( this.$router)
      this.$router.push('/roadmore')
    // this.$router.replace({path:'/loadmore'})
  },
    data(){
      return{
        appClass:"111"
      }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
